package com.bookshow.service;

import java.util.ArrayList;

import com.bookshow.dao.BookShowDAOImpl;
import com.bookshow.dao.IBookShowDAO;
import com.bookshow.dto.BookShow;
import com.bookshow.exception.ShowException;

public class BookShowServiceImpl implements IBookShowService{

	IBookShowDAO dao = new BookShowDAOImpl();
	
	@Override
	public ArrayList<BookShow> getAllShowDetails() throws ShowException {
		ArrayList<BookShow> alBook = new ArrayList<BookShow>();

		alBook = dao.getAllShowDetails();
		return alBook;
	}

	@Override
	public BookShow getShowById(String showId) throws ShowException {
		//BookShow sb = dao.getAllShowById(showId);
		ArrayList<BookShow> alBook = new ArrayList<BookShow>();
		alBook = dao.getAllShowDetails();
		System.out.println("In Service Layer");
		
		for(BookShow sb : alBook){
			System.out.println(sb);
		}
		
		BookShow sbb = null;

		for(BookShow sb : alBook){
			if(sb.getShowId().equals(showId)){
				sbb=sb; 
			}
		}
		System.out.println(sbb);
		return sbb;
	}

	@Override
	public int updateSeatForShow(int bookSeat, String showId) throws ShowException {
		
		
		return dao.updateSeatForShow(bookSeat,showId);
		
	}

}
