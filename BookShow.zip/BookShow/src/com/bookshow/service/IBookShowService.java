package com.bookshow.service;

import java.util.ArrayList;

import com.bookshow.dto.BookShow;
import com.bookshow.exception.ShowException;

public interface IBookShowService {

	ArrayList<BookShow> getAllShowDetails() throws ShowException;

	BookShow getShowById(String showId) throws ShowException;

	int updateSeatForShow(int bookSeat, String showId) throws ShowException;

}
