package com.bookshow.dao;

import java.util.ArrayList;

import com.bookshow.dto.BookShow;
import com.bookshow.exception.ShowException;

public interface IBookShowDAO {

	ArrayList<BookShow> getAllShowDetails() throws ShowException;

	BookShow getAllShowById(String showId);

	int updateSeatForShow(int bookSeat, String showId) throws ShowException;

}
