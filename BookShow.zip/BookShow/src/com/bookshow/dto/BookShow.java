package com.bookshow.dto;

public class BookShow {

	private String showId;
	private String showName;
	private String location;
	private String showDate;
	private int avSeats;
	private double priceTicket;
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getShowDate() {
		return showDate;
	}
	public void setShowDate(String showDate) {
		this.showDate = showDate;
	}
	public int getAvSeats() {
		return avSeats;
	}
	public void setAvSeats(int avSeats) {
		this.avSeats = avSeats;
	}
	public double getPriceTicket() {
		return priceTicket;
	}
	public void setPriceTicket(double priceTicket) {
		this.priceTicket = priceTicket;
	}
	
	@Override
	public String toString() {
		return "BookShow [showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", showDate=" + showDate
				+ ", avSeats=" + avSeats + ", priceTicket=" + priceTicket + "]";
	}
	
	
	
	
}
