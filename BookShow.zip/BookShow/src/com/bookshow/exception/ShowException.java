package com.bookshow.exception;

public class ShowException extends Exception{

	public ShowException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
